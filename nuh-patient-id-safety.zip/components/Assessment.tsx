
import React, { useState } from 'react';
import { AssessmentQuestion } from '../types';
import { 
  CheckCircle, 
  ArrowRight, 
  RotateCcw, 
  BarChart2, 
  ShieldCheck, 
  UserCheck, 
  Beaker, 
  Stethoscope, 
  Droplet, 
  AlertCircle 
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

// Questions derived directly from the OCR Compliance Checklist (SP-BQP-002-205-03)
const COMPLIANCE_QUESTIONS: AssessmentQuestion[] = [
  {
    id: 1,
    question: "ในขั้นตอนการระบุตัวตนทั่วไป คุณได้สแกน Barcode บนบัตรนัด/ป้ายข้อมือ และใช้ตัวบ่งชี้อย่างน้อย 2 อย่าง (ชื่อ-สกุล, วันเกิด, อายุ หรือเลขบัตรประชาชน) หรือไม่?",
    options: [
      "ปฏิบัติครบถ้วนทุกครั้ง",
      "ปฏิบัติเป็นบางครั้ง",
      "ไม่ได้ปฏิบัติ",
      "ไม่มีข้อมูล"
    ],
    category: 'behavior'
  },
  {
    id: 2,
    question: "เมื่อรับผู้ป่วยใหม่หรือรับย้าย คุณได้สแกน QR Code จากป้ายข้อมือทุกครั้งเพื่อยืนยันตัวตนหรือไม่?",
    options: [
      "ปฏิบัติครบถ้วนทุกครั้ง",
      "ปฏิบัติเป็นบางครั้ง",
      "ไม่ได้ปฏิบัติ",
      "ไม่มีข้อมูล"
    ],
    category: 'behavior'
  },
  {
    id: 3,
    question: "สำหรับการเจาะเลือด/เก็บสิ่งส่งตรวจ คุณได้ตรวจสอบความถูกต้องกับคำสั่งแพทย์ และติดสติกเกอร์ที่อุปกรณ์เก็บสิ่งส่งตรวจ 'ต่อหน้าผู้ป่วย' พร้อมตรวจสอบซ้ำอีกครั้งหรือไม่?",
    options: [
      "ปฏิบัติครบถ้วนทุกครั้ง",
      "ปฏิบัติเป็นบางครั้ง",
      "ไม่ได้ปฏิบัติ",
      "ไม่มีข้อมูล"
    ],
    category: 'behavior'
  },
  {
    id: 4,
    question: "กรณีส่งผู้ป่วยไปห้องผ่าตัดหรือทำหัตถการ คุณได้สแกน QR Code เพื่อตรวจสอบความถูกต้องเทียบกับป้ายข้อมือและแฟ้มประวัติผู้ป่วยหรือไม่?",
    options: [
      "ปฏิบัติครบถ้วนทุกครั้ง",
      "ปฏิบัติเป็นบางครั้ง",
      "ไม่ได้ปฏิบัติ",
      "ไม่มีข้อมูล"
    ],
    category: 'behavior'
  },
  {
    id: 5,
    question: "ในการให้ยา (Drug Administration) คุณได้ระบุตัวตนโดยการถามชื่อ-นามสกุล วันเดือนปีเกิด และตรวจสอบร่วมกับแบบบันทึกการให้ยา (MAR) ทุกครั้งหรือไม่?",
    options: [
      "ปฏิบัติครบถ้วนทุกครั้ง",
      "ปฏิบัติเป็นบางครั้ง",
      "ไม่ได้ปฏิบัติ",
      "ไม่มีข้อมูล"
    ],
    category: 'behavior'
  },
  {
    id: 6,
    question: "ในกระบวนการจองเลือด คุณได้ตรวจสอบคำสั่งใน HIS, ติดสติกเกอร์ต่อหน้าผู้ป่วย และให้ผู้ป่วย/ญาติช่วยตรวจสอบความถูกต้องก่อนเจาะเลือดหรือไม่?",
    options: [
      "ปฏิบัติครบถ้วนทุกครั้ง",
      "ปฏิบัติเป็นบางครั้ง",
      "ไม่ได้ปฏิบัติ",
      "ไม่มีข้อมูล"
    ],
    category: 'behavior'
  },
  {
    id: 7,
    question: "ก่อนการให้เลือด คุณได้ทำการตรวจสอบแบบ Independent Double Check (พยาบาล 2 คน) หรือใช้หลักการ 7 See (กรณีอยู่คนเดียว) อย่างเคร่งครัดหรือไม่?",
    options: [
      "ปฏิบัติครบถ้วนทุกครั้ง",
      "ปฏิบัติเป็นบางครั้ง",
      "ไม่ได้ปฏิบัติ",
      "ไม่มีข้อมูล"
    ],
    category: 'behavior'
  },
  {
    id: 8,
    question: "ทันทีก่อนเริ่มให้เลือด คุณได้สอบถามชื่อ-สกุล/วันเกิด และสแกน QR Code จากป้ายข้อมือผู้ป่วยอีกครั้งเพื่อความมั่นใจสูงสุดหรือไม่?",
    options: [
      "ปฏิบัติครบถ้วนทุกครั้ง",
      "ปฏิบัติเป็นบางครั้ง",
      "ไม่ได้ปฏิบัติ",
      "ไม่มีข้อมูล"
    ],
    category: 'behavior'
  }
];

const Assessment: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (optionIndex: number) => {
    const newAnswers = [...answers, optionIndex];
    setAnswers(newAnswers);
    if (currentStep < COMPLIANCE_QUESTIONS.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowResult(true);
    }
  };

  const calculateCompliance = () => {
    // Score 100% for index 0 (Fully Compliant), 50% for index 1, 0% for index 2
    // Index 3 (ไม่มีข้อมูล) is excluded from calculation
    let totalScore = 0;
    let validAnswersCount = 0;

    answers.forEach((ans) => {
      if (ans === 3) return; // Skip "ไม่มีข้อมูล"
      
      validAnswersCount++;
      if (ans === 0) totalScore += 100;
      else if (ans === 1) totalScore += 50;
    });

    if (validAnswersCount === 0) return 0;
    return Math.round(totalScore / validAnswersCount);
  };

  const complianceRate = calculateCompliance();

  const chartData = [
    { name: 'สอดคล้อง (Compliance)', value: complianceRate, color: '#2563eb' },
    { name: 'ความเสี่ยง (Gap)', value: 100 - complianceRate, color: '#e2e8f0' },
  ];

  if (showResult) {
    return (
      <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-slate-100 animate-fadeIn max-w-3xl mx-auto">
        <header className="text-center mb-8">
          <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <BarChart2 size={32} />
          </div>
          <h2 className="text-3xl font-bold text-slate-800">ดัชนีความสอดคล้อง (Compliance Index)</h2>
          <p className="text-slate-500">ผลการวิเคราะห์พฤติกรรมการระบุตัวตนของคุณ</p>
        </header>
        
        <div className="grid md:grid-cols-2 gap-10 items-center mb-10">
          <div className="h-64 relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={70}
                  outerRadius={95}
                  paddingAngle={5}
                  dataKey="value"
                  animationDuration={1500}
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-5xl font-black text-slate-800">{complianceRate}%</span>
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.2em]">Compliance</span>
            </div>
          </div>

          <div className="space-y-6">
            <div className={`p-6 rounded-3xl border-2 ${complianceRate >= 90 ? 'bg-green-50 border-green-200' : 'bg-amber-50 border-amber-200'}`}>
              <div className="flex items-center gap-3 mb-3">
                {complianceRate >= 90 ? <ShieldCheck className="text-green-600" /> : <AlertCircle className="text-amber-600" />}
                <h4 className={`font-bold ${complianceRate >= 90 ? 'text-green-800' : 'text-amber-800'}`}>
                  {complianceRate >= 90 ? 'ระดับความปลอดภัยสูงมาก' : 'ต้องการการปรับปรุงพฤติกรรม'}
                </h4>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed">
                {complianceRate === 100 
                  ? "ยอดเยี่ยม! คุณปฏิบัติตาม SOP SP-BQP-002-205-03 ได้ครบถ้วน 100% ช่วยลดความเสี่ยง Zero Identification Error ได้อย่างแท้จริง" 
                  : complianceRate >= 80 
                    ? "คุณมีพฤติกรรมความปลอดภัยที่ดี แต่ยังมีจุดที่อาจเกิดความผิดพลาดได้ แนะนำให้ทบทวนขั้นตอนการตรวจสอบหน้าผู้ป่วยและสแกน QR ทุกครั้ง" 
                    : "พบช่องว่างความเสี่ยงในการระบุตัวตน (Safety Gap) โปรดทบทวนขั้นตอนการทำ Independent Double Check และการติดสติกเกอร์ Lab ต่อหน้าผู้ป่วยโดยด่วน"}
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-slate-100 pt-8 flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button 
            onClick={() => {
              setCurrentStep(0);
              setAnswers([]);
              setShowResult(false);
            }}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-10 py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all hover:shadow-lg active:scale-95"
          >
            <RotateCcw size={20} />
            เริ่มต้นประเมินใหม่
          </button>
          <p className="text-[10px] text-slate-400 max-w-[200px] text-center sm:text-left font-medium">
            *ผลการประเมินนี้อ้างอิงจาก Compliance Checklist งานพยาบาลศัลยกรรม NUH
          </p>
        </div>
      </div>
    );
  }

  const question = COMPLIANCE_QUESTIONS[currentStep];

  const getStepIcon = (index: number) => {
    switch(index) {
      case 0: return <UserCheck size={24} />;
      case 1: return <ShieldCheck size={24} />;
      case 2: return <Beaker size={24} />;
      case 3: return <Stethoscope size={24} />;
      case 4: return <AlertCircle size={24} />;
      case 5: return <Droplet size={24} />;
      case 6: return <UserCheck size={24} />;
      case 7: return <ShieldCheck size={24} />;
      default: return <CheckCircle size={24} />;
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-6">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-black text-slate-800 mb-2">Self-Assessment Tool</h2>
        <p className="text-slate-500 font-medium">ตรวจสอบความสอดคล้องตามมาตรฐาน (SOP-SP-BQP-002-205-03)</p>
      </div>

      <div className="mb-12">
        <div className="flex justify-between items-center mb-4 px-2">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              {getStepIcon(currentStep)}
            </div>
            <div>
              <p className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Section {currentStep + 1}</p>
              <p className="text-slate-400 text-xs font-bold uppercase">Compliance Audit</p>
            </div>
          </div>
          <div className="text-right">
            <span className="text-2xl font-black text-slate-800">{currentStep + 1}</span>
            <span className="text-slate-300 font-bold"> / {COMPLIANCE_QUESTIONS.length}</span>
          </div>
        </div>
        <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden border border-slate-200 shadow-inner">
          <div 
            className="bg-blue-600 h-full transition-all duration-700 ease-out" 
            style={{ width: `${((currentStep + 1) / COMPLIANCE_QUESTIONS.length) * 100}%` }}
          ></div>
        </div>
      </div>

      <div className="bg-white p-10 rounded-[3rem] shadow-2xl shadow-blue-900/5 border border-slate-50 animate-slideUp">
        <h3 className="text-2xl font-bold text-slate-800 mb-10 leading-snug">
          {question.question}
        </h3>

        <div className="space-y-4">
          {question.options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(index)}
              className={`w-full text-left p-6 rounded-[1.5rem] border-2 transition-all duration-300 flex items-center justify-between group active:scale-[0.98] ${
                index === 0 
                ? 'bg-blue-50/30 border-slate-100 hover:border-blue-600 hover:bg-blue-600 hover:text-white' 
                : 'bg-slate-50 border-slate-100 hover:border-slate-300 hover:bg-white'
              }`}
            >
              <span className="font-bold text-lg">{option}</span>
              <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-colors group-hover:scale-110 ${
                index === 0 ? 'border-blue-200 group-hover:border-white' : 'border-slate-200'
              }`}>
                <ArrowRight size={16} />
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="mt-12 flex items-center justify-center gap-2 text-slate-400">
        <ShieldCheck size={14} />
        <p className="text-[10px] font-bold uppercase tracking-widest">Data Analysis & Safety Verification System</p>
      </div>
    </div>
  );
};

export default Assessment;
